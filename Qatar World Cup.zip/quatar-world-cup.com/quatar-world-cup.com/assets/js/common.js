const swiper = new Swiper(".swiper", {
    // direction: 'horizontal',
    loop: true,
    slidesPerView: 1,
    // autoHeight: true,
    autoplay: {
        delay: 5000,
    },
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
});

// Function fermer button,
function close() {
    document.location.href = "http://127.0.0.1:5500/DW/Devoir/quatar-world-cup.com/quatar-world-cup.com/index.html";
};   

